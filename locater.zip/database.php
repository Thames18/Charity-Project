<?php
$mysqli = new mysqli('localhost', 'u746480298_root', 'ydz2v7cPs5Np', 'u746480298_phple');
//$mysqli = new mysqli('localhost', 'dhanbee', 'foodbae123', 'foodbaee');

?>