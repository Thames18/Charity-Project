<?php session_start(); ?>
<link rel="stylesheet" href="form.css">
<div>
    <div class="welcome">
        </br>
         <h1> Welcome, <?= $_SESSION['username'] ?>! </h1> 
        
         <h3> Thank you for registering, we will be in contact soon.</h3>
    </div>


</div>

